# drbob

A new Flutter project.

## Getting Started
00. Names:
        I.      Doctor's Opinion
        II.     Dr Bob/Doctor Bob
        III.    drbob/DRAA (A.A. Dr., Dr. AA)
        IV.     Alcoholic Brain
        V.      Terminally Unique/Terminal Uniqueness
01. Add #ContactMe in #Setttings
02. Call2Action:
        A. Help translate
        B. iOS support
        C. Donate (Add donators section: +Patreon?)
                I. Roadmap (With X people requestions Y feature, i.e. iOS app)
        D. HireMe
        E. Errors in json/translation, bugs
        F. FAQ
        G. Roadmap (w/ timeline?)
                I. Prettify UI
                II. Add Favorite daily reflection? (Add star?)
03. DirectCommunication
04. Features:
        a. Daily Reflection Notification?