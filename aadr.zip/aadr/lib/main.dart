import 'package:flutter/material.dart';
import 'wrapper.dart';

void main() => runApp(AppWrapper());